package com.example.andrordclient;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class KernelActivity extends ActionBarActivity {
	private static KernelActivity THIS = null;
	private Button but_takeoff_land;
	private Button but_left;
	private Button but_right;
	private Button but_front;
	private Button but_back;
	private Button but_up;
	private Button but_down;
	private Handler TaskHandler;
	// test
	private TextView text_test;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mainlayout);
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void init() throws Exception {
		KernelActivity.THIS = this;
		// launch the task rounder
		// this.TaskHandler = KernelTask::getInstance();
		//this.TaskHandler = NetWorkLayer.getNetHandler();
		NetWorkLayer.getInstance(); // launch Net
		this.but_takeoff_land = (Button)findViewById(R.id.but_takeoff_land);
		this.but_takeoff_land.setText(R.string.Str_Connect);
		this.but_takeoff_land.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (((Button)v).getText().equals(KernelActivity.this.getResources().getString(R.string.Str_takoff))) {
					// send take off task
					KernelActivity.this.TaskHandler.sendEmptyMessage(v.getId()+10);
				} else if (((Button)v).getText().equals(KernelActivity.this.getResources().getString(R.string.Str_land))) {
					// send land task
					KernelActivity.this.TaskHandler.sendEmptyMessage(v.getId()+20);
				} else if (((Button)v).getText().equals(KernelActivity.this.getResources().getString(R.string.Str_Connect))) {
					// connect
					Intent intent = new Intent(KernelActivity.this, SocketBulidUp.class);
					startActivity(intent);
					/*if (NetWorkLayer.ifNetOk()) {
						// test
						KernelActivity.this.changeBasedOnNetState(true);
					} else {
						KernelActivity.this.changeBasedOnNetState(false);
					}*/
				}
				
			}
		});
		this.but_left = (Button)findViewById(R.id.but_left);
		this.but_left.setOnTouchListener(kernelListener);
		this.but_right = (Button)findViewById(R.id.but_right);
		this.but_right.setOnTouchListener(kernelListener);
		this.but_front = (Button)findViewById(R.id.but_front);
		this.but_front.setOnTouchListener(kernelListener);
		this.but_back = (Button)findViewById(R.id.but_back);
		this.but_back.setOnTouchListener(kernelListener);
		this.but_up = (Button)findViewById(R.id.but_up);
		this.but_up.setOnTouchListener(kernelListener);
		this.but_down = (Button)findViewById(R.id.but_down);
		this.but_down.setOnTouchListener(kernelListener);
		// disable all button
		this.DisableBut();
		// test
		this.text_test = (TextView)findViewById(R.id.text_test);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.kernel, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private OnTouchListener kernelListener = new OnTouchListener() {
		
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
			try {
				return KernelActivity.this.commandSender(v.getId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
	};
	
	private boolean commandSender(int ord) throws Exception {
		switch (ord) {
		case R.id.but_left: {
				Log.i("EXEC", "but_left pressing");
				break;
			}
		case R.id.but_right: {
				Log.i("EXEC", "but_right pressing");
				break;
			}
		case R.id.but_front: {
				Log.i("EXEC", "but_front pressing");
				break;
			}
		case R.id.but_back: { 
				Log.i("EXEC", "but_back pressing");
				break;
			}
		case R.id.but_up: {
			    Log.i("EXEC", "but_up pressing");
				break;
			}
		case R.id.but_down: { 
				Log.i("EXEC", "but_down pressing");
				break;
			}
		default: {
				Toast.makeText(KernelActivity.this, R.string.Str_Orderfailure, Toast.LENGTH_SHORT).show();
				return false;
			}
		}
		if (this.TaskHandler == null) {
			Toast.makeText(KernelActivity.this, "NULL", Toast.LENGTH_SHORT).show();
			this.TaskHandler = NetWorkLayer.getNetHandler();
		} else {
			this.TaskHandler.sendEmptyMessage(ord);
		}
		return true;
	}
	
	@Override
	protected void onDestroy() {
		if (this.TaskHandler != null) {
			this.TaskHandler = null;
			try {
				NetWorkLayer.NetClose();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//KernelTaskCenter.KernelClose(); // close the kernel center
		}
		super.onDestroy();
	}
	
	private void EnableBut() {
		//this.but_takeoff_land.setEnabled(true);
		this.but_takeoff_land.setText(R.string.Str_takoff);
		this.but_left.setEnabled(true);
		this.but_right.setEnabled(true);
		this.but_front.setEnabled(true);
		this.but_back.setEnabled(true);
		this.but_up.setEnabled(true);
		this.but_down.setEnabled(true);
		Toast.makeText(this, "Server Connected!", Toast.LENGTH_SHORT).show();
	}
	
	private void DisableBut() {
		//this.but_takeoff_land.setEnabled(false);
		this.but_takeoff_land.setText(R.string.Str_Connect);
		this.but_left.setEnabled(false);
		this.but_right.setEnabled(false);
		this.but_front.setEnabled(false);
		this.but_back.setEnabled(false);
		this.but_up.setEnabled(false);
		this.but_down.setEnabled(false);
		Toast.makeText(this, "Disconnect!", Toast.LENGTH_SHORT).show();
	}
	
	private void changeBasedOnNetState(boolean ifc) {
		if (ifc) {
			this.EnableBut();
			this.but_takeoff_land.setText(R.string.Str_takoff);
		} else {
			this.DisableBut();
			this.but_takeoff_land.setText(R.string.Str_Connect);
		}
	}
	
	public static class UpdateTask implements Runnable {
		private int taskOrd = -1;
		public UpdateTask(int ord) {
			// TODO Auto-generated constructor stub
			this.taskOrd = ord;
		}
		
		@Override
		public void run() {
			switch (this.taskOrd) {
			case 0: { // lost connection
				KernelActivity.THIS.changeBasedOnNetState(false);
				break;
			}
			case 1: { // connected
				KernelActivity.THIS.changeBasedOnNetState(true);
				break;
			}
			default: {
				// test
				// Toast.makeText(KernelActivity.THIS, "Send Succeed", Toast.LENGTH_SHORT).show();
			}
			}
		}
	}
}
