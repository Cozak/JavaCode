package com.example.andrordclient;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

public class NetWorkLayer {
	private static NetWorkLayer Noe = null;
	private static Handler netHandler = null;
	private Socket netSocket = null;
	private Handler mHandler = null;
	
	public static NetWorkLayer getInstance() {
		if (Noe == null) {
			Noe = new NetWorkLayer();
		}
		return Noe;
	}
	public static Handler getNetHandler() throws Exception {
		if (netHandler == null) {
			if (Noe == null) {
				NetWorkLayer.getInstance();
			} else {
				throw new Exception();
			}
		}
		return netHandler;
	}
	
	private NetWorkLayer() {
		mHandler = new Handler(Looper.getMainLooper());
		// launch local thread
		new Thread() {
			@Override
			public void run() {
				Looper.myLooper();
				Looper.prepare();
				netHandler = new Handler(Looper.myLooper()) {
					@Override
					public void handleMessage(Message msg) {
						// send task code and execute it
						NetWorkLayer.this.orderSender(msg.what);
						// tell the UI whether the order has sent out
					}
				};
				Looper.myLooper();
				Looper.loop();
			}
		}.start();
	}
	
	private static class SocketBT implements Runnable {
		private String[] sip = null;
		public SocketBT(String[] sip) {
			this.sip = sip;
		}
		@Override
		public void run() {
			SocketAddress saddr;
			try {
				saddr = new InetSocketAddress(InetAddress.getByName(sip[0]), Integer.parseInt(sip[1]));
				NetWorkLayer.Noe.netSocket.connect(saddr, 3000);
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
	public static int LaunchSocket(Context Act, String ip_port) {
		if (NetWorkLayer.Noe.ifAlive()) {
			return 0;
		}
		// launch a new activity to obtain the socket parameters
		if (NetWorkLayer.Noe == null || NetWorkLayer.netHandler == null) {
			Toast.makeText(Act, "Noe has died", Toast.LENGTH_SHORT).show();
			return 1;
		}
		// decode ip and port
		String[] sip = null; 
		if (!ip_port.matches("\\d{1,3}\\.\\d{1,3}+\\.\\d{1,3}+\\.\\d{1,3}+:\\d{1,5}")) {
			Toast.makeText(Act, "IP Illegal", Toast.LENGTH_SHORT).show();
			return 2; 
		}
		sip = ip_port.split(":");
		NetWorkLayer.Noe.netSocket = new Socket();
			
		NetWorkLayer.netHandler.sendMessage(Message.obtain(NetWorkLayer.netHandler, new NetWorkLayer.SocketBT(sip)));
		//if (NetWorkLayer.Noe.ifAlive()) {
		NetWorkLayer.Noe.mHandler.sendEmptyMessage(1); // notify main thread to get ready
		return 0;
		//}
	}
	
	private boolean ifAlive() {
		if (netSocket == null) {
			return false;
		}
		return netSocket.isConnected() && !netSocket.isClosed();
	}
	/*public static boolean ifNetOk() {
		if (Noe == null || netHandler == null) {
			// net init failed
			return false;
		}
		// test
		//Noe.mHandler.post(new KernelActivity.UpdateTask(1));
		Noe.ifconnected = true;
		// whether ready to work
		return Noe.ifconnected;
	}*/
	
	public static void NetClose() throws Exception {
		if (Noe != null) {
			if (netHandler != null) {
				netHandler.getLooper().quit(); // kill thread
			} else {
				throw new Exception();
			}
		}
	}
	
	
	// send message through socket
	private boolean orderSender(int ord) { // 0~5 0-takeoff 1-land 2-left 3-right 4-up 5-down
		if (!this.ifAlive()) {
			this.mHandler.sendEmptyMessage(0); // call main thread to disable the operation
			return false;
		}
		switch (ord) {
		case R.id.but_takeoff_land+10: {
			Log.i("Socket","Sending Take Off");
			break;
			}
		case R.id.but_takeoff_land+20: {
			Log.i("Socket","Sending Land");
			break;
		}
		case R.id.but_left:{
			Log.i("Socket","Sending Left");
			break;
			}
		case R.id.but_right: {
			Log.i("Socket","Sending Right");
			break;
			}
		case R.id.but_front: {
			Log.i("Socket","Sending Front");
			break;
			}
		case R.id.but_back: {
			Log.i("Socket","Sending Back");
			break;
			}
		case R.id.but_up: {
			Log.i("Socket","Sending Up");
			break;
			}
		case R.id.but_down: {
			Log.i("Socket","Sending Down");
			break;
			}
		default:;
		}
		return true;
	}
	
	
	// get message
	public void stateReceiver() {
		//.....
	}
	
	// get video
	public void videoReceiver() {
		
	}
	
}
