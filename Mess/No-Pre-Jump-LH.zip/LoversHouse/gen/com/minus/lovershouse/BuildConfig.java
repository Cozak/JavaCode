/** Automatically generated file. DO NOT MODIFY */
package com.minus.lovershouse;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}