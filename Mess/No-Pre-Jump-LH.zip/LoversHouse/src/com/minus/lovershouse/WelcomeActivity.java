package com.minus.lovershouse;

import com.minius.leadpage.GuideActivity;
import com.minus.lovershouse.R;
import com.minus.lovershouse.baseActivity.BroadCast;
//import com.minus.lovershouse.setting.ConfigActivity;
import com.minus.lovershouse.setting.PasswordActivity;
import com.minus.lovershouse.setting.UnlockGesturePasswordActivity;
import com.minus.lovershouse.singleton.GlobalApplication;
import com.minus.lovershouse.singleton.SelfInfo;
//import com.minus.sql_interface.Database;
//import com.minus.table.UserTable;
import com.minus.xsocket.asynsocket.protocol.Protocol;
import com.minus.xsocket.handler.ConnectHandler;
import com.umeng.analytics.MobclickAgent;
import com.umeng.fb.FeedbackAgent;
//import com.umeng.message.IUmengRegisterCallback;
import com.umeng.message.PushAgent;
//import com.umeng.message.UmengRegistrar;
import com.umeng.update.UmengUpdateAgent;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
//import android.annotation.SuppressLint;
import android.app.Activity;
//import android.content.ClipboardManager;
//import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
//import android.text.TextUtils;
import android.view.Menu;


public class WelcomeActivity extends BroadCast {

	private Handler welcomeHandler = null;

	private PushAgent mPushAgent;
 
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        
        SelfInfo.getInstance().setDefault();
        ConnectHandler.getInstance().connectToServer();
        
        MobclickAgent.updateOnlineConfig(this);
        //UmengUpdateAgent.update(this);//�Զ�����
        FeedbackAgent agent = new FeedbackAgent(GlobalApplication.getInstance());
        agent.sync();
        
        mPushAgent = PushAgent.getInstance(GlobalApplication.getInstance());
		mPushAgent.enable();
//		String deviceToken = PushAgent.getInstance(GlobalApplication.getInstance()).getRegistrationId();
//		testOut.setText(deviceToken);
//		String a = getDeviceInfo(getApplicationContext());
    }
    
/*��ȡ�������ú���
public static String getDeviceInfo(Context context) {
    try{
      org.json.JSONObject json = new org.json.JSONObject();
      android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager) context
          .getSystemService(Context.TELEPHONY_SERVICE);
  
      String device_id = tm.getDeviceId();
      
      android.net.wifi.WifiManager wifi = (android.net.wifi.WifiManager) context.getSystemService(Context.WIFI_SERVICE);
          
      String mac = wifi.getConnectionInfo().getMacAddress();
      json.put("mac", mac);
      
      if( TextUtils.isEmpty(device_id) ){
        device_id = mac;
      }
      
      if( TextUtils.isEmpty(device_id) ){
        device_id = android.provider.Settings.Secure.getString(context.getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
      }
      
      json.put("device_id", device_id);
      
      return json.toString();
    }catch(Exception e){
      e.printStackTrace();
    }
  return null;
}*/

    
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(this.welcomeHandler == null){
			this.welcomeHandler = new MyHandler();
			
		}
		Message msg =welcomeHandler.obtainMessage();
		msg.what = 1;
		welcomeHandler.sendMessageDelayed(msg, 3000);

	}


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		this.welcomeHandler = null;
	}


	private  class MyHandler extends Handler {
	

		@Override
		public void handleMessage(Message msg) {
	
			switch (msg.what) {  
		     case 1:
		    	 
		    	 SharedPreferences mSP = getApplicationContext()
					.getSharedPreferences(Protocol.PREFERENCE_NAME,
							Activity.MODE_PRIVATE);
		    	boolean isFirstRun = mSP.getBoolean("IsFirstRun", true);
		    	if(isFirstRun){
		    		 Intent intent = new Intent();
	                  intent.setClass(WelcomeActivity.this,GuideActivity.class);
	                  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);   
	                  startActivity(intent);
	                  WelcomeActivity.this.finish();
		    	} else {
		    		String dbTitle = mSP.getString("LastUser", "");
		    	    if(dbTitle.equals("")){
		    		  Intent intent = new Intent();
	                  intent.setClass(WelcomeActivity.this, RegisterActivity.class);
	                  intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);  
	                  startActivity(intent);
	                  WelcomeActivity.this.finish();
		    	    } else {
		    		  SharedPreferences mSP1  = GlobalApplication.getInstance().getSharedPreferences(dbTitle,Activity.MODE_PRIVATE);
		    		  if (mSP1.getBoolean("isProtected",false)) {
		    				if (mSP1.getBoolean("isNum",true)) {
		    					Intent regIntent =new Intent(WelcomeActivity.this, PasswordActivity.class);
		    					Bundle regBundle = new Bundle();
		    			        regBundle.putString("who", "6");
		    			        regIntent.putExtras(regBundle);
		    			        regIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);  
		    					startActivity(regIntent);
		    					WelcomeActivity.this.finish();
		    				} else {
		    					Intent regIntent =new Intent(WelcomeActivity.this, UnlockGesturePasswordActivity.class);
		    					regIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		    					Bundle regBundle = new Bundle();
		    			        regBundle.putString("who", "6");
		    			        regIntent.putExtras(regBundle);
		    					startActivity(regIntent);
		    					WelcomeActivity.this.finish();
		    				}
		    				
		    			} else {
		    	                  Intent intent = new Intent();
		    	                  intent.setClass(WelcomeActivity.this,MainActivity.class);
		    	                  intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
		    	                  intent.putExtra("who", 2);
//		    	                  intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);   
		    	                  startActivity(intent);
		    	                  WelcomeActivity.this.finish();
		    			}
		    	  }
		    	}
	                break;
		     case 2:
		    	 
		    	 break;
		     case 3:
		    	
		    	 break;
	            default:
	                break;
			}
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_welcome, menu);
        return true;
    }
}
