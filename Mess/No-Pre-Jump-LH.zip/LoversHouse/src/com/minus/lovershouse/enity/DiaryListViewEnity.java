package com.minus.lovershouse.enity;

public class DiaryListViewEnity {
	  private String name; //  smallname
	  
	  private String account; 

	    private String title;  //title

	    private String editDate;  
	    
	    private String content;
	    
	    private String initDate;
	    
	    private int isNew;
	    
	    private boolean isComing;
	    
      
	 
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}



		public String getAccount() {
			return account;
		}



		public void setAccount(String account) {
			this.account = account;
		}



		public String getTitle() {
			return title;
		}



		public void setTitle(String title) {
			this.title = title;
		}



		public String getEditDate() {
			return editDate;
		}



		public void setEditDate(String editDate) {
			this.editDate = editDate;
		}



		public String getContent() {
			return content;
		}



		public void setContent(String content) {
			this.content = content;
		}



		public String getInitDate() {
			return initDate;
		}



		public void setInitDate(String initDate) {
			this.initDate = initDate;
		}



		public int getIsNew() {
			return isNew;
		}



		public void setIsNew(int isNew) {
			this.isNew = isNew;
		}

       

		

		public boolean isComing() {
			return isComing;
		}

		public void setComing(boolean isComing) {
			this.isComing = isComing;
		}

		public DiaryListViewEnity() {
			super();
	    }

}
