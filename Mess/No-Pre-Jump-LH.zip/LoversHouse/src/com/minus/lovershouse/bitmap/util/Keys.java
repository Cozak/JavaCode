package com.minus.lovershouse.bitmap.util;

public class Keys {

	
	public static final String PATH= "path";
	public static final String INDEX= "index";
}
