package com.minus.gallery;

import uk.co.senab.photoview.PhotoViewAttacher;
import uk.co.senab.photoview.PhotoViewAttacher.OnPhotoTapListener;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.minus.lovershouse.R;
import com.minus.lovershouse.singleton.GlobalApplication;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.ImageSize;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;


public class GalleryImageDetailFragment extends Fragment {
	private String mImageUrl;
	private ImageView mImageView;
	private ProgressBar progressBar;
	private PhotoViewAttacher mAttacher;
	private int imgHeight=800;
	private int imgWidth = 360;
	DisplayImageOptions options;

	
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	public static GalleryImageDetailFragment newInstance(String imageUrl) {
		final GalleryImageDetailFragment f = new GalleryImageDetailFragment();

		final Bundle args = new Bundle();
		args.putString("url", imageUrl);
		f.setArguments(args);

		return f;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mImageUrl = getArguments() != null ? getArguments().getString("url") : null;
		
		
		options = new DisplayImageOptions.Builder()
		.showImageForEmptyUri(R.drawable.ic_empty)
		.showImageOnFail(R.drawable.ic_error)
		.resetViewBeforeLoading(true)
		.cacheOnDisk(true)
		.imageScaleType(ImageScaleType.EXACTLY)
		.bitmapConfig(Bitmap.Config.RGB_565)
		.considerExifParams(true)
		.displayer(new FadeInBitmapDisplayer(300))
		.build();
		
		this.imgHeight = GlobalApplication.getInstance().getScreenHeigh();
		this.imgWidth = GlobalApplication.getInstance().getScreenWidth();
		

	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		final View v = inflater.inflate(R.layout.image_detail_fragment, container, false);
		mImageView = (ImageView) v.findViewById(R.id.image);
		mAttacher = new PhotoViewAttacher(mImageView);
		
		mAttacher.setOnPhotoTapListener(new OnPhotoTapListener() {
			
			@Override
			public void onPhotoTap(View arg0, float arg1, float arg2) {
				FrameLayout  mRL = (FrameLayout)getActivity().findViewById(R.id.img_top);
				if(mRL.isShown()){
				mRL.setVisibility(View.GONE);
				}else{
					mRL.setVisibility(View.VISIBLE);
				}
			}
		});
		
		progressBar = (ProgressBar) v.findViewById(R.id.loading);
		return v;
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		
	
		starReadPic();
		
		
		
	}
	
	public void starReadPic(){
		 ImageSize targetSize = new ImageSize(this.imgWidth, this.imgHeight); 
	imageLoader.loadImage("file://"+mImageUrl, targetSize, options, new SimpleImageLoadingListener() {
		@Override
		public void onLoadingStarted(String imageUri, View view) {
			progressBar.setVisibility(View.VISIBLE);
		}

		@Override
		public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
			String message = null;
			switch (failReason.getType()) {
			case IO_ERROR:
				message = "���ش���";
				break;
			case DECODING_ERROR:
				message = "ͼƬ�޷���ʾ";
				break;
			case NETWORK_DENIED:
				message = "��������";
				break;
			case OUT_OF_MEMORY:
				message = "�ڴ����";
				break;
			case UNKNOWN:
				message = "δ֪����";
				break;
			}
			Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
			progressBar.setVisibility(View.GONE);
		}

		@Override
		public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
			progressBar.setVisibility(View.GONE);
			mImageView.setImageBitmap(loadedImage);
			mAttacher.update();
		}
	});
	
				
			
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
//	       System.out.println("onDestroy = "+mImageUrl);  
		super.onDestroy();
//		imageLoader.clearMemoryCache();
	}
	
	  @Override  
      public void onDestroyView(){  
//          System.out.println("onDestroyView = "+mImageUrl);  
//          this.imageLoader.
          this.imageLoader.cancelDisplayTask(mImageView);
          super.onDestroyView();  
      }  
        
}
