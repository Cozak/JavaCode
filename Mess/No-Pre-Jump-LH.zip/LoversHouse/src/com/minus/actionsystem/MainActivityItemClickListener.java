package com.minus.actionsystem;

public interface MainActivityItemClickListener {
	void onclick(int item);
}
