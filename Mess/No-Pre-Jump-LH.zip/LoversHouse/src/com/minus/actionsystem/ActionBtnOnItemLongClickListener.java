package com.minus.actionsystem;

public interface  ActionBtnOnItemLongClickListener {
	void onActionBtnLongclick(int item);
}
